/**
 *    Created by tomokokawase
 *    On 2018/7/20
 *    阿弥陀佛，没有bug!
 */

const GANACHE_PORT = "7545";
const GANACHE_CLI_PORT = "8545";
const GANACHE_URL = "127.0.0.1";
const GANACHE_PROTOCOL = "http";

module.exports = {
    WEB3_PORT : GANACHE_CLI_PORT,
    WEB3_URL  : GANACHE_URL,
    WEB3_PROTOCAL : GANACHE_PROTOCOL
};

